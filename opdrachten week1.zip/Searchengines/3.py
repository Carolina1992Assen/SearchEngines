#!/usr/bin/python3
# This program will build a postings list
# where the key is a word
# and where the values are the tweet identifiers in which that word occurs
# Author: Carlijn Assen
# Date: 08/09/2018

import sys
import pickle


def main():
    word_list = []
    post_dict = {}
    docs = pickle.load(open('docs.pickle', 'rb'))
    for item in docs:
        word_list = word_list + docs[item][2].split()

    words = sorted(set(word_list))

    for word in words:
        matches = []
        for item in docs:
            if word in docs[item][2].split():
                matches = matches + [item]
                post_dict[word] = set(matches)

    with open('post_dict.pickle', 'wb') as f:
        pickle.dump(post_dict, f)

if __name__ == "__main__":
    main()
